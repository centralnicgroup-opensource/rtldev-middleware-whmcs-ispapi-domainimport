## [1.0.1](https://github.com/hexonet/whmcs-ispapi-domainimport/compare/v1.0.0...v1.0.1) (2019-02-28)


### Bug Fixes

* **dep-bump:** whmcs-ispapi-helper to v1.0.6 ([bcdbe2c](https://github.com/hexonet/whmcs-ispapi-domainimport/commit/bcdbe2c))

# 1.0.0 (2019-02-27)


### Bug Fixes

* **PDO:** rewrite for better PDO usage incl. NULL value replacement ([e3e9914](https://github.com/hexonet/whmcs-ispapi-domainimport/commit/e3e9914))
* **pkg:** domain list output in textarea ([bdeab61](https://github.com/hexonet/whmcs-ispapi-domainimport/commit/bdeab61))
